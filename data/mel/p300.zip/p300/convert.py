import torch
import numpy as np
from os import listdir

if __name__ == '__main__':
    for f in listdir():
        try:
            arr = np.load(f)
            tensor = torch.from_numpy(arr)
            torch.save(tensor, '{}.pt'.format(f))
        except:
            print("Non numpy")
        
